
const myTimeout = setTimeout(()=>{console.log('hi')}, 5000);
const myTimeout2 = setTimeout(()=>{console.log('hello')}, 6000);
const myTimeout3 = setTimeout(()=>{console.log('jkhu')}, 1000);